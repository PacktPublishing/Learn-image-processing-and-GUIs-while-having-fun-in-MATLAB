function varargout = stoicBird1(varargin)
% STOICBIRD1 MATLAB code for stoicBird1.fig
%      STOICBIRD1, by itself, creates a new STOICBIRD1 or raises the existing
%      singleton*.
%
%      H = STOICBIRD1 returns the handle to a new STOICBIRD1 or the handle to
%      the existing singleton*.
%
%      STOICBIRD1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STOICBIRD1.M with the given input arguments.
%
%      STOICBIRD1('Property','Value',...) creates a new STOICBIRD1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before stoicBird1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to stoicBird1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help stoicBird1

% Last Modified by GUIDE v2.5 02-Oct-2018 07:13:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @stoicBird1_OpeningFcn, ...
                   'gui_OutputFcn',  @stoicBird1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before stoicBird1 is made visible.
function stoicBird1_OpeningFcn(hObject, eventdata, handles, varargin)


%% create the bird

nPerPart = 50;

% specify XY points for the body
handles.bodyX = 3*cos(linspace(0,2*pi,nPerPart));
handles.bodyY = 5*sin(linspace(0,2*pi,nPerPart));

% specify XY points for the head
handles.headX = 1+1.5*cos(linspace(0,2*pi,nPerPart))';
handles.headY = 5+1.5*sin(linspace(0,2*pi,nPerPart))';

% specify XY points for the wing
handles.wingX = cos(linspace(0,2*pi,nPerPart))' - 1;
handles.wingY = 4*sin(linspace(0,2*pi,nPerPart))';

% shift all points to be nonnegative
lowPoint = min(handles.bodyY);
lefPoint = min(handles.bodyX);

handles.bodyX = handles.bodyX - lefPoint;
handles.headX = handles.headX - lefPoint;
handles.wingX = handles.wingX - lefPoint;

handles.bodyY = handles.bodyY - lowPoint;
handles.headY = handles.headY - lowPoint;
handles.wingY = handles.wingY - lowPoint;



handles.bodyh = patch(handles.birdAxis,handles.bodyX,handles.bodyY,'r');
handles.headh = patch(handles.birdAxis,handles.headX,handles.headY,'b');
handles.wingh = patch(handles.birdAxis,handles.wingX,handles.wingY,'y');
set(handles.birdAxis,'xlim',[0 100],'ylim',[0 100],'xtick',[],'ytick',[])


%% set the velocity vector

handles.vLineh = plot(handles.traj_axis,[0 .5],[0 .7],'ko-','markerfacecolor','k','markersize',10);
set(handles.traj_axis,'xlim',[0 1],'ylim',[0 1],'xtick',[],'ytick',[]);

% make the line invisible to mouse clicks
set(handles.vLineh,'HitTest','off');

% add functionality to the axis
set(handles.traj_axis,'ButtonDownFcn',{@traj_axis_ButtonDownFcn,handles})

%%

updatepos_Callback(hObject, eventdata, handles)


% Choose default command line output for stoicBird1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes stoicBird1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = stoicBird1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function traj_axis_ButtonDownFcn(hObject, eventdata, handles)

% get the current mouse location
xy = get(handles.traj_axis,'CurrentPoint');

% update the velocity vector line
set(handles.vLineh,'XData',[0 xy(1,1)],'YData',[0 xy(1,2)])

asdf = 5;


function xpos_str_Callback(hObject, eventdata, handles)
% hObject    handle to xpos_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xpos_str as text
%        str2double(get(hObject,'String')) returns contents of xpos_str as a double


% --- Executes during object creation, after setting all properties.
function xpos_str_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xpos_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ypos_str_Callback(hObject, eventdata, handles)
% hObject    handle to ypos_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ypos_str as text
%        str2double(get(hObject,'String')) returns contents of ypos_str as a double


% --- Executes during object creation, after setting all properties.
function ypos_str_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ypos_str (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in updatepos.
function updatepos_Callback(hObject, eventdata, handles)

% set initial position via vertical and horizontal shifts
x = str2double(get(handles.xpos_str,'String'));
y = str2double(get(handles.ypos_str,'String'));

% update bird parts
set(handles.headh,'XData',handles.headX+x,'YData',handles.headY+y);
set(handles.bodyh,'XData',handles.bodyX+x,'YData',handles.bodyY+y);
set(handles.wingh,'XData',handles.wingX+x,'YData',handles.wingY+y);


% --- Executes on button press in go_button.
function go_button_Callback(hObject, eventdata, handles)


%% setup the physics

% set initial position via vertical and horizontal shifts
x = str2double(get(handles.xpos_str,'String'));
y = str2double(get(handles.ypos_str,'String'));

% get the XY location of the velocity vector
vx = get(handles.vLineh,'XData');
vy = get(handles.vLineh,'YData');

theta = atan2(vy(2),vx(2));

% gravity (m/s^2)
g  = 9.81;

% initial velocity (m/s)
v0 = 5*norm([ vx(2) vy(2) ]);

%% run animation


% start the timer (in seconds)
tic;

while y>0
    
    % stop to look
    pause(.1)
    
    % update X and Y coordinates based on physics
    x = x + v0*toc*cos(theta);
    y = y + v0*toc*sin(theta) - (g*toc^2)/2;
    
    if y<0, y=0; end
    
    % update bird parts
    set(handles.headh,'XData',handles.headX+x,'YData',handles.headY+y);
    set(handles.bodyh,'XData',handles.bodyX+x,'YData',handles.bodyY+y);
    set(handles.wingh,'XData',handles.wingX+x,'YData',handles.wingY+y);
    
    % update the XY locations of the bird
    set(handles.xpos_str,'String',num2str(round(x,1)))
    set(handles.ypos_str,'String',num2str(round(y,1)))
    
end

%%

pause(1)
% update the bird location
set(handles.xpos_str,'String','0')
set(handles.ypos_str,'String','70')

updatepos_Callback(hObject, eventdata, handles)


asdf = 5;
