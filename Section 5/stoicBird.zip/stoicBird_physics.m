
%% setup the physics

% set initial position via vertical and horizontal shifts
x = 0;
y = 70;

theta = pi/8;

% gravity (m/s^2)
g  = 9.81;

% initial velocity (m/s)
v0 = 5;

%% setup the figure

h = plot(x,y,'ko','markerfacecolor','k','markersize',20);
set(gca,'xlim',[0 100],'ylim',[0 100])

%% run animation

% start the timer (in seconds)
tic;

while y>0
    
    % update bird parts
    set(h,'XData',x,'YData',y);
    
    % stop to look
    pause(.1)
    
    % update X and Y coordinates based on physics
    x = x + v0*toc*cos(theta);
    y = y + v0*toc*sin(theta) - (g*toc^2)/2;
    
end

%%

