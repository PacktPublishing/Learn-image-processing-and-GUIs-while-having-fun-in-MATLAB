
%% create the bird


nPerPart = 50;

% specify XY points for the body
bodyX = 3*cos(linspace(0,2*pi,nPerPart));
bodyY = 5*sin(linspace(0,2*pi,nPerPart));

% specify XY points for the head
headX = 1+1.5*cos(linspace(0,2*pi,nPerPart))';
headY = 5+1.5*sin(linspace(0,2*pi,nPerPart))';

% specify XY points for the wing
wingX = cos(linspace(0,2*pi,nPerPart))' - 1;
wingY = 4*sin(linspace(0,2*pi,nPerPart))';

% shift all points to be nonnegative
lowPoint = min(bodyY);
lefPoint = min(bodyX);

bodyX = bodyX - lefPoint;
headX = headX - lefPoint;
wingX = wingX - lefPoint;

bodyY = bodyY - lowPoint;
headY = headY - lowPoint;
wingY = wingY - lowPoint;



figure(1), clf; 
bodyh = patch(bodyX,bodyY,'r');
headh = patch(headX,headY,'b');
wingh = patch(wingX,wingY,'y');
axis([0 1 0 1]*100)

%% setup the physics

% set initial position via vertical and horizontal shifts
x = 0;
y = 70;

theta = pi/8;

% gravity (m/s^2)
g  = 9.81;

% initial velocity (m/s)
v0 = 5;

%% run animation


% start the timer (in seconds)
tic;

while y>0
    
    % stop to look
    pause(.1)
    
    % update X and Y coordinates based on physics
    x = x + v0*toc*cos(theta);
    y = y + v0*toc*sin(theta) - (g*toc^2)/2;
    
    if y<0, y=0; end
    
    % update bird parts
    set(headh,'XData',headX+x,'YData',headY+y);
    set(bodyh,'XData',bodyX+x,'YData',bodyY+y);
    set(wingh,'XData',wingX+x,'YData',wingY+y);
    
end

%%
