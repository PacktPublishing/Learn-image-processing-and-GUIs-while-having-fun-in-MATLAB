%%%
% 
% Create 3D magic-eye pictures
% 
%%%
%     COURSE: Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: Create 3D magic-eye (autostereogram) pictures
% Instructor: sincxpress.com
%
%%%

%%
%
% VIDEO: Image depth via 3D rotation
%
%% 

% create surface
peeks = peaks(50);


figure(1), clf
ax1 = axes('Position',[.18 .25 .4 .5]);
surf(ax1,peeks)
shading interp
axis(ax1,'off')
view([-35 20])

ax2 = axes('Position',[.45 .25 .4 .5]);
surf(ax2,peeks)
shading interp
axis(ax2,'off')
view([-30 20])

%% repeat for Korean elevation

k = load('korea.mat');

% let's look at the "flat" map
figure(2), clf
surf(k.map)
shading interp
axis off


% now for the 3D visualization
figure(3), clf
ax1 = axes('Position',[.3 .25 .3 .5]);
surf(ax1,k.map)
shading interp
axis(ax1,'off')
view([-20 25])

ax2 = axes('Position',[.52 .25 .3 .5]);
surf(ax2,k.map)
shading interp
axis(ax2,'off')
view([-15 25])

%%
% 
% 
%%% Layer depth via horizontal spacing
% 
% 
%%


peeks = peaks(50);


x{1} = -.1:.20:.9;
x{2} = -.1:.19:.9;
x{3} = -.1:.21:.9;
x{4} = -.1:.22:.9;
x{5} = -.1:.18:.9;

y = linspace(.1,.6,length(x));

figure(4), clf
clear ax

for xi=1:length(x)
    for i=1:length(x{xi})
        ax(xi,i) = axes('Position',[x{xi}(i) y(xi) .25 .25]);
        surf(ax(xi,i),peeks)
        shading interp
        axis(ax(xi,i),'off','square')
    end
end

%% now for an animation

% loop over animation frames
for i=1:1000
    
    % adjust 2nd row
    for ii=1:length(x{2})
        % get axis positions
        p = get(ax(2,ii),'Position');
        p(1) = p(1) + .0001;
        set(ax(2,ii),'Position',p);
    end
    
    % repeat for 4th row
    for ii=1:length(x{4})
        p = get(ax(4,ii),'Position');
        p(1) = p(1) - .0002;
        set(ax(4,ii),'Position',p);
    end
    pause(.01)
end


%%
% 
% 
%%% Hiding the surface in a background
% 
% 
%%



imsize = 400;
depth  = 100;
tilesize = round(imsize/5);

% create 3D image to embed
magicI = peaks(imsize);
magicI = magicI - min(magicI(:));
magicI = magicI./max(magicI(:));
%%% note: image must be integer values!
magicI = round(magicI*depth/2); % divisor controls height


% create tile to warp onto image
[X,Y] = meshgrid(linspace(-2,2,5)); % first, create
g2d   = exp( -(X.^2+Y.^2) );        % a 2D Gaussian
tile  = conv2(randn(tilesize),g2d,'same');


% construct the magic-eye row-wise
for rowi = 1:size(magicI,1)
    
    
    % loop over columns
    for coli=imsize:-1:1
        
        
        % left "block" of image is the tile
        if coli>imsize-tilesize
            
            % XY coordinates in tile
            tilex = mod(rowi-1,tilesize)+1;
            tiley = mod(coli-1,tilesize)+1;
            
            % replace in image
            magicI(rowi,coli) = tile(tilex,tiley);
            
        % right part of image is shifted tiles
        else
            
            % pixel idx
            colidx = coli + tilesize - magicI(rowi,coli)+1;
            
            % replace in image
            magicI(rowi,coli) = magicI(rowi,colidx);
        end
        
        
    end % end column loop
end % end row loop


% show the final result!
figure(4), clf
imagesc(magicI)
colormap bone
set(gca,'xtick',[],'ytick',[])


%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
