%%%
% 
% Low-rank approximation of Obama and Trump
%    n.b., results here do not reflect policy or politics.
% 
%%%
%     COURSE: Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: Low-rank approximations of famous people
% Instructor: sincxpress.com
%
%%%


%% import and show images

% import
obama = imread('BO.png');
trump = imread('DT.png');

% show images
figure(1), clf
subplot(121)
imshow(obama)

subplot(122)
imshow(trump)

%% flattened (2D) versions of both images

obama = mean(obama,3);
trump = mean(trump,3);

%% singular value decomposition of both images

[Uo,So,Vo] = svd( obama );
[Ut,St,Vt] = svd( trump );


% show singular value spectra
figure(2), clf, hold on
plot(diag(So),'bo-','markersize',12,'markerfacecolor','w')
plot(diag(St),'rs-','markersize',12,'markerfacecolor','w')
set(gca,'xlim',[0 50],'yscale','log')
xlabel('Component number'), ylabel('Singular values (\sigma)')
legend({'Obama';'Trump'})

%% first 5 components of each image

figure(3), clf

for i=1:5
    
    % compute low-rank approximations
    lowappO = Uo(:,1:i) * So(1:i,1:i) * Vo(:,1:i)';
    lowappT = Ut(:,1:i) * St(1:i,1:i) * Vt(:,1:i)';
    
    % show the images
    subplot(2,5,i)
    imagesc(lowappO), axis off, axis image
    title([ 'Rank-' num2str(i) ' approx.' ])
    
    subplot(2,5,i+5)
    imagesc(lowappT), axis off, axis image
    title([ 'Rank-' num2str(i) ' approx.' ])
end
colormap gray

%% movie of images getting sharper with more rank-1 matrices

% max number of ranks
ranks2show = 80;
[appErrorsO,appErrorsT] = deal( zeros(ranks2show,1) );


% setup the movie background
figure(4), clf
colormap gray

% random placeholder for Obama
subplot(221)
hO = imagesc(randn(size(obama)));
axis off, axis image
tO = title('#44');
set(gca,'clim',[0 255])

% random placeholder for Trump
subplot(222)
hT = imagesc(randn(size(trump)));
axis off, axis image
tT = title('#45');
set(gca,'clim',[0 255])

% approximation errors
subplot(212), hold on
heO = plot(1:ranks2show,appErrorsO,'bo-','markerfacecolor','w');
heT = plot(1:ranks2show,appErrorsT,'rs-','markerfacecolor','w');
set(gca,'xlim',[0 ranks2show+1])
xlabel('Matrix rank'), ylabel('Error magnitude (a.u.)')
legend({'Obama errors';'Trump errors'})


% show the movie
for i=1:ranks2show
    
    % compute low-rank approximations
    lowappO = Uo(:,1:i) * So(1:i,1:i) * Vo(:,1:i)';
    lowappT = Ut(:,1:i) * St(1:i,1:i) * Vt(:,1:i)';
    
    % update the two images
    set(hO,'CData',lowappO)
    set(tO,'string',[ 'Rank-' num2str(rank(lowappO)) ' approx.' ])
    
    set(hT,'CData',lowappT)
    set(tT,'string',[ 'Rank-' num2str(rank(lowappT)) ' approx.' ])
    
    
    % error compared to original image
    appErrorsO(i) = sum( (obama(:)-lowappO(:)).^2 );
    appErrorsT(i) = sum( (trump(:)-lowappT(:)).^2 );
    
    % update error plots
    set(heO,'xdata',1:i,'ydata',appErrorsO(1:i))
    set(heT,'xdata',1:i,'ydata',appErrorsT(1:i))
    
    
    % update the figure
    pause(.1)
end


%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
