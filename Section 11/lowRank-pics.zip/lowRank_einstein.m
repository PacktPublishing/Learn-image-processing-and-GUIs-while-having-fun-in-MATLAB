%%%
% 
% Low-rank approximation of Albert Einstein
%    No, not THE actual Einstein; just his picture.
% 
%%%
%     COURSE: Learn image processing by coding silly games in MATLAB
%    PROJECT: Low-rank approximations of famous people
% Instructor: sincxpress.com
%
%%%

%% import and show image

ein = imread('einstein.jpg');

figure(1), clf
imshow(ein)

%% now for SVD

% need a "flattened" (2D) version
einflat = mean(ein,3);


% SVD of the matrix
[U,S,V] = svd(einflat);


% show 16 low-rank approximations
figure(2), clf

for ai=1:16
    
    % low-rank approximation
    lowapp = U(:,1:ai) * S(1:ai,1:ai) * V(:,1:ai)';
    
    subplot(4,4,ai)
    imagesc(lowapp), axis off, axis image
    title([ 'Rank-' num2str(rank(lowapp)) ' approx.' ])
end
colormap gray


%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
