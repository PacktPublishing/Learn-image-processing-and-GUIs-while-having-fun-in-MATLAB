%%%
% 
% Family photos
%    Make your mom angry by changing your precious family photos (digital only!)
% 
%%%
%     COURSE: Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: Annoy your parents by blurring family photos
% Instructor: sincxpress.com
%
%%%

%% how to import a picture into MATLAB

% extensions to filter
extfilt = {'*.jpg;*.png'};

% pick a file
[filename,filepath] = uigetfile(extfilt,'Pick an image file!');


% now import picture
pic = imread([ filepath filename ]);

% inspect
whos pic


%% two options for viewing pictures

% option 1: made for pictures
figure(1), clf
subplot(121)
imshow(pic)

% option 2: generic for visualizing any matrix
subplot(122)
imagesc(pic)
axis off
axis image

%%

%% smoothing with Gaussian

% create a 2D Gaussian
k = 31;
s = 1;
[X,Y] = meshgrid(linspace(-2,2,k));
g2d = exp( -(X.^2+Y.^2) / s );
g2d = g2d ./ sum(g2d(:));


% have a look
figure(2), clf
subplot(221)
imagesc(g2d)
axis image, axis off
title('Smoothing kernel')

% optional x/y axis limits to compare the size against the image
set(gca,'xlim',[-1 1]*size(pic,2)/2,'ylim',[-1 1]*size(pic,1)/2)


% color channel labels
cchan = {'red';'green';'blue'};


% initialize smoothed picture
picSmooth = pic;

% loop over color channels
for i=1:3
    
    % convolve slice with Gaussian
    picSmooth(:,:,i) = conv2(double(pic(:,:,i)),g2d,'same');
    
    % show that slice
    subplot(2,3,i+3)
    imagesc(picSmooth(:,:,i))
    title(cchan{i}), axis square
    set(gca,'xtick',[],'ytick',[])
    axis image
end

% show the final result
subplot(222)
imagesc(picSmooth)
axis image, axis off

%%


%% smoothing with mean

% create a 2D mean-smoothing kernel
k = 31;
kernel = ones(k) / k^2;

% have a look
figure(3), clf
subplot(221)
imagesc(kernel)
axis off, axis image
title('Smoothing kernel')
set(gca,'xlim',[-1 1]*size(pic,2)/2,'ylim',[-1 1]*size(pic,1)/2)

% color channel labels
cchan = {'red';'green';'blue'};

% initialize smoothed picture
picSmooth = pic;

% loop over color channels
for i=1:3
    
    % convolve slice with mean-smoothing kernel
    picSmooth(:,:,i) = conv2(double(pic(:,:,i)),kernel,'same');
    
    % show that slice
    subplot(2,3,i+3)
    imagesc(picSmooth(:,:,i))
    title(cchan{i}), axis square
    set(gca,'xtick',[],'ytick',[])
end

% show the final result
subplot(222)
imagesc(picSmooth)
axis image, axis off

%%


%% sharpen the image

% create a 2D sharpening kernel
k = 31; % should be an add number
kernel = -ones(k);
kernel(ceil(k/2),ceil(k/2)) = k^2;


% have a look
figure(4), clf
subplot(221)
imagesc(kernel)
axis image, axis off
title('Sharpening kernel')

% color channel labels
cchan = {'red';'green';'blue'};

% initialize sharpened picture
picSharp = pic;

% loop over color channels
for i=1:3
    
    % convolve slice with sharpening kernel
    picSharp(:,:,i) = conv2(double(pic(:,:,i)),kernel,'same');
    
    % show that slice
    subplot(2,3,i+3)
    imagesc(picSharp(:,:,i))
    title(cchan{i}), axis image
    set(gca,'xtick',[],'ytick',[])
end

% show the final result
subplot(222)
imagesc(picSharp)
axis image
set(gca,'xtick',[],'ytick',[])


%%


%% clean speckle noise using median filter

picN = pic;

nPix = size(pic,1)*size(pic,2);

% add noise
for i=1:3
    pix = randi(nPix,[round(nPix*.2),1]);
    tmp = pic(:,:,i);
    tmp(pix) = 255;
    picN(:,:,i) = tmp;
end

figure(5), clf
subplot(121)
imshow(picN)
title('Noise added')


%% now for cleaning

% dimensions of the picture
picdim = size(pic);

% size of kernel
k = 3;

% loop over the different color channels
for colori=1:3
    
    % extract this color slice of the picture
    tmp = picN(:,:,colori);
    
    % find pixels equally its maxima
    [ri,ci] = find( tmp==max(tmp(:)) );
    
    
    % loop over all maxima pixels (don't filter all pixels)
    for i=1:length(ci)
        
        % define boundaries for submatrix
        bndRL = max(ri(i)-k,1);
        bndRU = min(ri(i)+k,picdim(1));
        bndCL = max(ci(i)-k,1);
        bndCU = min(ci(i)+k,picdim(2));
        
        submat = tmp(bndRL:bndRU,bndCL:bndCU);
        picN(ri(i),ci(i),colori) = median(submat(:));
    end
    
    
end % end loop over color channels

% finally, visualize
subplot(122)
imshow(picN)
title('Denoised')

%%


%% save picture


% select file
[filename,filepath] = uiputfile('*.*','File and folder for output');



%%% option 1: imwrite with double-precision, norm to [0 1]
img2write = double(picSmooth);
img2write = img2write - min(img2write(:));
img2write = img2write ./ max(img2write(:));
imwrite(img2write,[filepath filename '1.png' ])


%%% option 2: imwrite with uint8
imwrite(picSmooth,[filepath filename '2.png' ])


%%% option 3: print an entire figure
figure(6), clf
imagesc(picSmooth)
axis image, axis off
print([ filepath filename '3.png' ],'-dpng')
close(6)

%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
