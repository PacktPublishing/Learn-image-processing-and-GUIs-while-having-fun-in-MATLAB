%%%
% 
% Dot kinetogram
%    Create a stimulus array of dots that move 
%    dynamically and coherently over time.
% 
%%%
%     COURSE: Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: Structure from motion
% Instructor: sincxpress.com
%
%%%

clear

%% specifiable parameters

% maximum possible coherence
max_coher = 100;

% dot speed (in pixels per step)
dotspeed = 2;

% stimulus duration in seconds
stim_dur = 5;

% total number of dots
numdots = 300;

% increments of speed changes (divided into stimulus duration)
nSpeedIncs = 30;


%% initialize coherence functions

% coherence functions (first initialize)
coherfunc = zeros(4,nSpeedIncs);

coherfunc(1,:) = linspace(0,numdots,nSpeedIncs); % linear increase
coherfunc(2,:) = linspace(numdots,0,nSpeedIncs); % linear decrease
coherfunc(3,:) = numdots*(.5-cos(2*pi*(0:nSpeedIncs-1)/nSpeedIncs)/2); % scaled Hann window
coherfunc(4,:) = numdots - coherfunc(3,:); % inverse Hann


% initialize random dot locations
dotsx = rand(numdots,1)*600-300;
dotsy = rand(numdots,1)*600-300;
nReplacements = zeros(numdots,1);


% setup figure
figure(1), clf
dotsh = scatter(dotsx,dotsy,40,randperm(numdots),'filled','markeredgecolor','k');
set(gca,'xlim',[-300 300],'ylim',[-300 300],'xtick',[],'ytick',[])
title('Press Ctrl-c to stop')

%% start the movies!

% continue until Ctrl-c is pressed
while 1
    
    % randomly choose a coherence level and condition
    motdir = sign(randn);
    condit = ceil(rand*4);
    
    % initialize increment number
    incnum = 1;
    numdots2move = coherfunc(condit,incnum);
    
    % start timer
    [trialstart,incdelay] = deal( tic );
    
    
    %% actual stimulus presentation
    
    while toc(trialstart) < stim_dur
        
        
        % increment time block
        if toc(incdelay) > stim_dur/nSpeedIncs
            
            % increase counter
            incnum = incnum+1;
            
            % reset timer
            incdelay = tic;
        end
        
        
        
        
        % setup the dots
        for di=1:numdots
            
            % replace dot locations, either randomly or by intelligent design
            if di<=coherfunc(condit,incnum) && nReplacements(di)<randi([10 40],1)
                
                % update XY locations
                dotsx(di) = dotsx(di)+dotspeed*motdir;
                dotsy(di) = dotsy(di);
                
                % update counter
                nReplacements(di) = nReplacements(di)+1;
            else
                % random XY locations
                dotsx(di) = rand*600-300;
                dotsy(di) = rand*600-300;
                nReplacements(di)=0;
            end
        end
        
        % the universe wraps around itself
        dotsx(dotsx>+300) = -300;
        dotsx(dotsx<-300) = +300;
        
        % now this frame is set, display!
        set(dotsh,'XData',dotsx,'YData',dotsy)
        drawnow;
    end
    
    % visual break between conditions
    pause(1)
    
end


%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
