%%%
% 
% 3D example with cylinder
%    Make a visual illusion of a rotating cylinder using dots.
% 
%%%
%     Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: Structure from motion
% Instructor: sincxpress.com
%
%%%

%%

% space-time parameters
ndots = 100;
nframes = 800;


% initial random dot locations
x = rand(ndots,1)*2*pi;
y = rand(ndots,1);


% setup figure
figure(1), clf
h = scatter(x,y,100,randn(ndots,1),'filled','markeredgecolor','k');
set(gca,'xlim',[-1 1],'ylim',[0 1],'xtick',[],'ytick',[],'clim',[-1 1])
axis square


% start clock timer
tic;


% loop over frames
for framei=1:nframes
    
    % slide the y-coordinates
    y(1:2:end) = y(1:2:end) + .001;
    y(2:2:end) = y(2:2:end) - .001;
    
    % fix out-of-bound dots
    y(y>1) = 0;
    y(y<0) = 1;
    
    % update x locations by cosine
    xx = cos(2*pi*.1*toc+x);
    
    % update dot locations
    set(h,'XData',xx,'YData',y);
    pause(.01)
end


%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.
