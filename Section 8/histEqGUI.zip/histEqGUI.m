function varargout = histEqGUI(varargin)
% HISTEQGUI MATLAB code for histEqGUI.fig
%      HISTEQGUI, by itself, creates a new HISTEQGUI or raises the existing
%      singleton*.
%
%      H = HISTEQGUI returns the handle to a new HISTEQGUI or the handle to
%      the existing singleton*.
%
%      HISTEQGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HISTEQGUI.M with the given input arguments.
%
%      HISTEQGUI('Property','Value',...) creates a new HISTEQGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before histEqGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to histEqGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help histEqGUI

% Last Modified by GUIDE v2.5 28-Oct-2018 18:43:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @histEqGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @histEqGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before histEqGUI is made visible.
function histEqGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to histEqGUI (see VARARGIN)

% Choose default command line output for histEqGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes histEqGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = histEqGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in import_button.
function import_button_Callback(hObject, eventdata, handles)

% select and import a picture
[filename,pathname] = uigetfile('*.*','Import a picture');
pic = imread([ pathname filename ]);

% put the picture into the original picture axis
imagesc(handles.axes_img_orig,pic)
set(handles.axes_img_orig,'xtick',[],'ytick',[])

% compute and display the histograms for each color channel
cla(handles.axes_hist_orig)
hold(handles.axes_hist_orig,'on')
c = 'rgb';
for ci=1:3
    [y,x] = hist( nonzeros(double(pic(:,:,ci))) ,256);
    plot(handles.axes_hist_orig,x,y,c(ci),'linewidth',2)
end
set(handles.axes_hist_orig,'xtick',[],'ytick',[],'xlim',[0 256])

function code4histeq_Callback(hObject, eventdata, handles)
% hObject    handle to code4histeq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of code4histeq as text
%        str2double(get(hObject,'String')) returns contents of code4histeq as a double


% --- Executes during object creation, after setting all properties.
function code4histeq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to code4histeq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in apply2red.
function apply2red_Callback(hObject, eventdata, handles)
% hObject    handle to apply2red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of apply2red


% --- Executes on button press in apply2green.
function apply2green_Callback(hObject, eventdata, handles)
% hObject    handle to apply2green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of apply2green


% --- Executes on button press in apply2blue.
function apply2blue_Callback(hObject, eventdata, handles)
% hObject    handle to apply2blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of apply2blue


% --- Executes on button press in applyEq.
function applyEq_Callback(hObject, eventdata, handles)

% get requested color channels
whichcols = [ get(handles.apply2red,'Value') get(handles.apply2green,'Value') get(handles.apply2blue,'Value') ];

newpic = get(handles.axes_img_orig.Children,'CData');

% apply the equalizations
for ci=1:3
    if whichcols(ci)
        newpic(:,:,ci) = histeq(newpic(:,:,ci),eval( get(handles.code4histeq,'String') ));
    end
end


% put the picture into the original picture axis
imagesc(handles.axes_img_mod,newpic)
set(handles.axes_img_mod,'xtick',[],'ytick',[])

% compute and display the histograms for each color channel
cla(handles.axes_hist_mod)
hold(handles.axes_hist_mod,'on')
c = 'rgb';
for ci=1:3
    [y,x] = hist( nonzeros(double(newpic(:,:,ci))) ,256);
    plot(handles.axes_hist_mod,x,y,c(ci),'linewidth',2)
end
set(handles.axes_hist_mod,'xtick',[],'ytick',[],'xlim',[0 256])




asdf = 234;






