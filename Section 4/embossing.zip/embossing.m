function varargout = embossing(varargin)
% EMBOSSING FILTER
%    Show off your amazing MATLAB image processing skills by embossing
%    anything and everything.
% 
%%%
%     COURSE: Learn image processing by coding silly games in MATLAB
%    PROJECT: Impress your boss with embossing filters
% Instructor: sincxpress.com
%
%%%


% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @embossing_OpeningFcn, ...
                   'gui_OutputFcn',  @embossing_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before embossing is made visible.
function embossing_OpeningFcn(hObject, eventdata, handles, varargin)
handles.pich = imagesc(handles.picaxis);
handles.origPic = get(handles.pich,'CData');
axis(handles.picaxis,'off')
set(handles.picaxis,'ydir','reverse')
colormap(handles.picaxis,'gray')

% specify colors
handles.buttoncolors = [ 1 0 0; .94 .94 .94; 0 1 0 ];



% Choose default command line output for embossing
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = embossing_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function update_filter_button(hObject, eventdata, handles)
currval = sscanf(get(hObject,'String'),'%g');
newval = currval+1 + (-3*(currval+1>1));
set(hObject,'String',num2str(newval),'backgroundcolor',handles.buttoncolors(newval+2,:))


% --- Executes on button press in b11.
function b11_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b12_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b13_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b21_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b22_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b23_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b31_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b32_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)
function b33_Callback(hObject, eventdata, handles)
   update_filter_button(hObject, eventdata, handles)


% --- Executes on button press in filterButton.
function filterButton_Callback(hObject, eventdata, handles)

% extract the filter
bossfilt = zeros(3);
for i=1:3
    for j=1:3
        eval([ 'bossfilt(i,j) = sscanf(get(handles.b' num2str(i) num2str(j) ',''String''),''%g'');' ])
    end
end

% apply filter using conv2
if sum(bossfilt(:)==0)==i*j
    set(handles.pich,'CData',handles.origPic)
else
    newim = conv2(handles.origPic,bossfilt,'same');
    set(handles.pich,'CData',newim)
end


% --- Executes on button press in importButton.
function importButton_Callback(hObject, eventdata, handles)

% select new file
[filename,filepath] = uigetfile('*.*','Select a picture');
newpic = imread([filepath filename]);
if numel(size(newpic))>2
    newpic = mean(newpic,3);
end

% replace original image data
handles.origPic = newpic;

% update axis
set(handles.pich,'CData',newpic);

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in exportPicture.
function exportPicture_Callback(hObject, eventdata, handles)
% select file
[filename,filepath] = uiputfile('*.*','File and folder for output');

% already an extension suggested?
wheredot = strfind(filename,'.');

% extract image and normalize to [0 1]
im = get(handles.pich,'CData');
im = im-min(im(:));
im = im./max(im(:));

% write out file
if isempty(wheredot)
    % no extension provided, assume png
    imwrite(im,[filepath filename '.png' ]);
else
    imwrite(im,[filepath filename]);
end



%% done.


% Interested in more courses? See sincxpress.com 
% Use code MXC-DISC4ALL for the lowest price for all courses.

