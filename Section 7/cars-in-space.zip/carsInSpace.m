% CARS IN SPACE!!!
%    Get your car into outer space with a super-expensive rocket.
% 
%%%
%     COURSE: Learn image processing and GUIs while having fun in MATLAB
%    PROJECT: How to get a car into outer space
% Instructor: sincxpress.com
%
%%%
function carsInSpace

% load in the images
car = imread('car.jpg');
car = car(85:270,30:612,:);

space = imread('galaxies.jpg');

%% setup the figure

screensize = get(0,'screensize');

figh = figure('Position',screensize*.7);
set(figh,'name','Cars in space!','numbertitle','off','menubar','none')


%%% put outer space into the figure
spaceax = axes('Position',[0 0 .9 1]);
imagesc(spaceax,space)

%%% add the car into outer space
carax = axes('Position',[.4 .3 .2 .4]);
carh = imagesc(carax,car);
axis(carax,'image','off')
set(carh,'AlphaData',0)

%% add a slider bar to control invisibility

% add slider to blend the car into/out of space
blendh = uicontrol('style','slider','units','normalized','Callback',{@blend,carh});
set(blendh,'Position',[.95 .5 .02 .4]);

% add a button to start/stop the car's movement
uicontrol('style','togglebutton','units','normalized',...
    'String','Drive!!','fontsize',20,'Backgroundcolor',[0 1 0],'Position',[.9 .2 .1 .1],...
    'Callback',{@drive,carax})


%% subfunction definitions

function blend(source,eventdata,carh)
    alphdat = get(source,'Value');
    set(carh,'AlphaData',alphdat);
end


function drive(source,eventdata,carax)
    
    % turn the button red
    set(source,'BackgroundColor',[1 0 0],'String','STOP!!!')
    
    % need to know the current position of the car axis
    origpos = get(carax,'Position');
    
    while get(source,'Value')==1
        
        % move the car around (define a new xy coordinate)
        c = clock;
        newx = origpos(3) + rand/10*cos(2*pi*.1*c(6));
        newy = origpos(4) + rand/10*sin(2*pi*.1*c(6));
        
        
        % update the location of the axis
        set(carax,'Position',[ newx newy origpos(3:4) ])
        
        pause(.1)
    end
    
    % reset the button color and text
    set(source,'BackgroundColor',[0 1 0],'String','Drive!!')
    
    
    asdf=4;
end


end








